<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Reservaciones
 * @author     Wilmer <wilmeraguear@hotmail.es>
 * @copyright  Wilmer
 * @license    Licencia Pública General GNU versión 2 o posterior. Consulte LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_reservaciones');
if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_reservaciones')) {
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
?>
<?php if ($this->item) : ?>

	<div class="item_fields">
		<table class="table">
			
		</table>
	</div>
	
	<?php
else:
	echo JText::_('COM_RESERVACIONES_ITEM_NOT_LOADED');
endif;
